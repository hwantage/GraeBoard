import{D as e,I as t,L as n,T as r,_t as i,k as a,pt as o}from"./presentation-sequence-DGjUbwoK.js";import{a as s,c,h as l,i as u,l as d,o as f,s as p,u as m}from"./pdf-export-pages-DD86mG3x.js";var h=`/* Class rules for \`element-dom.ts\` nodes; the HTML player and PDF pages inline this file. */
:root {
  color-scheme: light;
  --video-backdrop: #000000;
  /* The player's board; connector labels mask their line with it. */
  --canvas: #f7f7f8;
  /* Text with the default family inherits this stack, as it inherits the app's in the editor. */
  font-family:
    ui-sans-serif,
    system-ui,
    -apple-system,
    'Segoe UI',
    Roboto,
    'Helvetica Neue',
    'Apple SD Gothic Neo',
    'Malgun Gothic',
    sans-serif;
}
/* Content never intercepts pointer events except text links; frames are the overview's targets. */
.uc-el,
.uc-img {
  position: absolute;
  pointer-events: none;
  /* Frames carry negative z-indices (largest at the bottom), so content always paints above. */
  z-index: 0;
}
.uc-link {
  pointer-events: auto;
  cursor: pointer;
}
.uc-connector svg,
.uc-shape svg {
  position: absolute;
  inset: 0;
  overflow: visible;
}
.uc-img {
  max-width: none;
  display: block;
}
`;function g(e,t,n={}){let r=document.createElement(e);return r.className=t,_(r,n),r}function _(e,t){let n=e.style;for(let[e,r]of Object.entries(t))r!==void 0&&(n[e]=r)}function v(e,t){_(e,{left:`${t.x}px`,top:`${t.y}px`,width:`${t.width}px`,height:`${t.height}px`})}function y(e,t,n,r={}){let i=g(`div`,e,{...r,...d(n)});return i.textContent=t,i}function b(e,t){let n=t.link!==void 0,r=i(t.text,t.link);r.some(e=>e.url!==void 0)&&e.replaceChildren(...r.map(e=>{if(e.url===void 0)return e.text;let t=g(`a`,o,m(n));return t.href=e.url,t.target=`_blank`,t.rel=`noopener noreferrer`,t.setAttribute(`draggable`,`false`),t.tabIndex=-1,t.addEventListener(`mousedown`,e=>e.preventDefault()),n&&(t.title=e.url),t.textContent=e.text,t}))}var x=`http://www.w3.org/2000/svg`;function S(e,t){let n=document.createElementNS(x,e);for(let[e,r]of Object.entries(t))r!==void 0&&n.setAttribute(e,String(r));return n}function C(e){return Object.fromEntries(Object.entries(e).filter(e=>e[1]!==void 0).map(([e,t])=>[e.replace(/[A-Z]/g,e=>`-${e.toLowerCase()}`),t]))}function w(e){let{width:t,height:n}=e,{tag:r,...i}=a(e),o=S(`svg`,{width:t,height:n,viewBox:`0 0 ${t} ${n}`});return o.append(S(r,{...i,...C(c(e))})),o}function T(e,t){let n=E(e,t);return n&&`rotation`in e&&_(n,f(e)),n}function E(e,t){switch(e.type){case`video`:{let t=g(`div`,`uc-el`);return t.dataset.videoId=e.id,v(t,e),t}case`text`:{let t=y(`uc-el uc-text`,e.text,e.textStyle);return b(t,e),v(t,e),_(t,{height:`auto`,minHeight:`${e.height}px`,clipPath:r(e.clip)}),t}case`shape`:{let t=g(`div`,`uc-el uc-shape`);if(v(t,e),t.append(w(e)),e.text!==``){let n=g(`div`,`uc-shape-label`,p(e));n.append(y(`uc-text`,e.text,e.textStyle)),t.append(n)}return t}case`image`:{let n=t.assets[e.assetId];if(!n)return null;let r=g(`img`,`uc-img`);return r.src=n.data,r.alt=``,r.draggable=!1,v(r,e),r}case`frame`:return null;case`connector`:return D(e,t)}}function D(r,i){let a=t(i,r),o=e(r),c=g(`div`,`uc-el uc-connector`);v(c,o);let d=S(`svg`,{width:o.width,height:o.height,viewBox:`${o.x} ${o.y} ${o.width} ${o.height}`}),{line:f,markers:p}=s(r,l(r,a));for(let e of[f,...p])d.append(S(`path`,C(e)));if(c.append(d),r.label!==``){let e=n(r,a);c.append(y(`uc-text uc-connector-label`,r.label,r.textStyle,u(e,o,r.textStyle.fontSize)))}return c}export{h as n,T as t};